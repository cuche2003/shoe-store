package com.j2ee.test.shoemodule.constants;

/**
 * @author DELL
 */
public class ShoeModulePortletKeys {

	public static final String SHOEMODULE =
		"com_j2ee_test_shoemodule_ShoeModulePortlet";

}